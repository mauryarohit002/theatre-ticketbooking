<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class movie_model extends CI_Model{

	function insert($table,$data){
		return $this->db->insert($table,$data);
		
	}

	function getwheredb($table,$data){
		// print_r($data);
		$this->db->where($data);
		$query=$this->db->get($table);
		 // print_r($query);
		 if($query->num_rows()>0){
		 	$this->db->where($data);
			return $this->db->get($table)->result_array();

		 }
		 else{
		 	return "error";
		 }
	}

	function getdb($table){
		return $this->db->get($table)->result_array();
	}

	
}