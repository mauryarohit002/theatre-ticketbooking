<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Movie extends CI_Controller {
	  function __construct() {
        parent::__construct();

        $this->load->model('movie_model');
      }  
	
	public function index()
	{
		$this->load->view('index');
	}

	function register(){
		$this->load->view('register');
	}

	function register_action(){
		// $this->load->view('register');
		 //print_r($_POST);

		 $this->form_validation->set_rules('uname','name','required|alpha');
		 $this->form_validation->set_rules('umobile','mobile no.','required|exact_length[10]|numeric');
		 $this->form_validation->set_rules('uemail','email','required|is_unique[muser.uemail]|valid_email');
		 $this->form_validation->set_rules('upass','password','required|min_length[4]|max_length[12]');
		 $this->form_validation->set_rules('ucpass','Confirm password','required|min_length[4]|max_length[12]|matches[upass]');
		 if(!$this->form_validation->run()){
		 	echo json_encode(array('status'=>'error','desc'=>validation_errors()));
		 }
		 else{
		 		$arr=array(
		 				'uname'=>$_POST['uname'],
		 				'umobile'=>$_POST['umobile'],
		 				'uemail'=>$_POST['uemail'],
		 				'upass'=>sha1($_POST['upass'])
		 		);

		 		$res=$this->movie_model->insert('muser',$arr);
		 		if($res>0){
		 			echo json_encode(array('status'=>'success','desc'=>'user added successfully.'));
		 		}
		 		else{
		 			echo json_encode(array('status'=>'error','desc'=>'user added failed.'));
		 		}
		 }

	}

	function login(){
		$this->load->view('login');
	}

	function login_action(){

		 $this->form_validation->set_rules('uemail','email','required|valid_email');
		 $this->form_validation->set_rules('upass','password','required|min_length[4]|max_length[12]');
		
		if(!$this->form_validation->run()){
		 	echo json_encode(array('status'=>'error','desc'=>validation_errors()));
		 }

		else{
			$arr=array(
				'uemail'=>$_POST['uemail'],
				'upass'=>sha1($_POST['upass'])
			);
			$res=$this->movie_model->getwheredb('muser',$arr);
			if(is_array($res) && $res!='error'){
				 // print_r($res[0]['uname']);
				$sesdata=array(
					'name'=>$res[0]['uname'],
					'mobile'=>$res[0]['umobile'],
					'email'=>$res[0]['uemail'],
					'status'=>$res[0]['ustatus']
				);
				
				$this->session->set_userdata($sesdata);
				// print_r($_SESSION);
		 			echo json_encode(array('status'=>'success','desc'=>'login successfully.'));
				
			}
			else{
		 			echo json_encode(array('status'=>'error','desc'=>'invalid email and password.'));

			}
		} 		 


	}

	function logout(){
		$array_items=array('name','mobile','email','status');
				$this->session->unset_userdata($array_items);
				$this->session->sess_destroy();
				redirect(base_url('index.php/movie/index'));

	}

	function city(){
		// echo 'test';
		$this->load->view('add-city');
	}

	function city_action(){
		$this->form_validation->set_rules('cname','city','required|alpha_numeric_spaces');
		if(!$this->form_validation->run()){
		 	echo json_encode(array('status'=>'error','desc'=>validation_errors()));
		}		
		else{

			$res=$this->movie_model->insert('city',$_POST);
			if($res>0){
		 			echo json_encode(array('status'=>'success','desc'=>'city added successfully.'));

			}
			else{
		 			echo json_encode(array('status'=>'error','desc'=>'city added failed.'));

			}
		}
	}

	function area(){
		$res['city']=$this->movie_model->getdb('city');
		$this->load->view('area',$res);
	}
	
	function area_action(){
		 //print_r($_POST);
		 $this->form_validation->set_rules('aname','Area name','required|alpha_numeric_spaces');
		 $this->form_validation->set_rules('cityid','city','required|numeric');
		 if(!$this->form_validation->run()){
		 	echo json_encode(array('status'=>'error','desc'=>validation_errors()));

		 }
		 else{
			$arr=array(
				'aname'=>$_POST['aname'],
				'acid'=>$_POST['cityid']
			);

			$res=$this->movie_model->insert('area',$arr);
			// print_r($res);
			if($res>0){
		 		echo json_encode(array('status'=>'success','desc'=>'area added successfully.'));

			}
			else{
		 		echo json_encode(array('status'=>'error','desc'=>'area added failed.'));

			}
		 }
		
		
	}

	function theater(){
		$res['city']=$this->movie_model->getdb('city');
		$this->load->view('theater',$res);
	}

	
}
