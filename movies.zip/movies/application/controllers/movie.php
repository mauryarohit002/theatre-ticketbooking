<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Movie extends CI_Controller {
	  function __construct() {
        parent::__construct();

        $this->load->model('movie_model');
      }  
	
	public function index()
	{
		$this->load->view('index');
	}

	function register(){
		$this->load->view('register');
	}

	function register_action(){
		// $this->load->view('register');
		 //print_r($_POST);

		 $this->form_validation->set_rules('uname','name','required|alpha');
		 $this->form_validation->set_rules('umobile','mobile no.','required|exact_length[10]|numeric');
		 $this->form_validation->set_rules('uemail','email','required|is_unique[muser.uemail]|valid_email');
		 $this->form_validation->set_rules('upass','password','required|min_length[4]|max_length[12]');
		 $this->form_validation->set_rules('ucpass','Confirm password','required|min_length[4]|max_length[12]|matches[upass]');
		 if(!$this->form_validation->run()){
		 	echo json_encode(array('status'=>'error','desc'=>validation_errors()));
		 }
		 else{
		 		$arr=array(
		 				'uname'=>$_POST['uname'],
		 				'umobile'=>$_POST['umobile'],
		 				'uemail'=>$_POST['uemail'],
		 				'upass'=>sha1($_POST['upass'])
		 		);

		 		$res=$this->movie_model->insert('muser',$arr);
		 		if($res>0){
		 			echo json_encode(array('status'=>'success','desc'=>'user added successfully.'));
		 		}
		 		else{
		 			echo json_encode(array('status'=>'error','desc'=>'user added failed.'));
		 		}
		 }

	}

	function login(){
		$this->load->view('login');
	}

	function login_action(){

		 $this->form_validation->set_rules('uemail','email','required|valid_email');
		 $this->form_validation->set_rules('upass','password','required|min_length[4]|max_length[12]');
		
		if(!$this->form_validation->run()){
		 	echo json_encode(array('status'=>'error','desc'=>validation_errors()));
		 }

		else{
			$arr=array(
				'uemail'=>$_POST['uemail'],
				'upass'=>sha1($_POST['upass'])
			);
			$res=$this->movie_model->getwheredb('muser',$arr);
			if(is_array($res) && $res!='error'){
				 // print_r($res[0]['uname']);
				$sesdata=array(
					'name'=>$res[0]['uname'],
					'mobile'=>$res[0]['umobile'],
					'email'=>$res[0]['uemail'],
					'status'=>$res[0]['ustatus']
				);
				
				$this->session->set_userdata($sesdata);
				// print_r($_SESSION);
		 			echo json_encode(array('status'=>'success','desc'=>'login successfully.'));
				
			}
			else{
		 			echo json_encode(array('status'=>'error','desc'=>'invalid email and password.'));

			}
		} 		 


	}

	function logout(){
		$array_items=array('name','mobile','email','status');
				$this->session->unset_userdata($array_items);
				$this->session->sess_destroy();
				redirect(base_url('index.php/movie/index'));

	}

	function city(){
		// echo 'test';
		$this->load->view('add-city');
	}

	function city_action(){
		$this->form_validation->set_rules('cname','city','required|alpha_numeric_spaces');
		if(!$this->form_validation->run()){
		 	echo json_encode(array('status'=>'error','desc'=>validation_errors()));
		}		
		else{

			$res=$this->movie_model->insert('city',$_POST);
			if($res>0){
		 			echo json_encode(array('status'=>'success','desc'=>'city added successfully.'));

			}
			else{
		 			echo json_encode(array('status'=>'error','desc'=>'city added failed.'));

			}
		}
	}

	function area(){
		$res['city']=$this->movie_model->getdb('city');
		$this->load->view('area',$res);
	}
	
	function area_action(){
		 //print_r($_POST);
		 $this->form_validation->set_rules('aname','Area name','required|alpha_numeric_spaces');
		 $this->form_validation->set_rules('cityid','city','required|numeric');
		 if(!$this->form_validation->run()){
		 	echo json_encode(array('status'=>'error','desc'=>validation_errors()));

		 }
		 else{
			$arr=array(
				'aname'=>$_POST['aname'],
				'acid'=>$_POST['cityid']
			);

			$res=$this->movie_model->insert('area',$arr);
			// print_r($res);
			if($res>0){
		 		echo json_encode(array('status'=>'success','desc'=>'area added successfully.'));

			}
			else{
		 		echo json_encode(array('status'=>'error','desc'=>'area added failed.'));

			}
		 }
		
		
	}

	function theater(){
		$res['city']=$this->movie_model->getdb('city');
		$this->load->view('theater',$res);
	}

	function theater_action(){
		$arr=array('acid'=>$_POST['acid']);
		$res=$this->movie_model->getwheredb('area',$arr);
		// print_r($res);
		if(is_array($res) && $res!='error'){
		 	// echo json_encode(array('status'=>'success','desc'=>));
			echo "<option value=' '>please select area </option>";
			foreach ($res as $val) {
				$id=$val['aid'];
				echo "<option value='$id' >".$val['aname']."</option>";
			}
		}
		else{
			echo "<option value=''>No area found.</option>";
		}
	}

	function theater_insertaction(){
		// print_r($_POST);
		$this->form_validation->set_rules('tname','Theater name','required|alpha_numeric_spaces');
		 $this->form_validation->set_rules('cityid','city','required|numeric');
		 $this->form_validation->set_rules('areaid','area','required|numeric');

		 if(!$this->form_validation->run()){
		 	echo json_encode(array('status'=>'error','desc'=>validation_errors()));

		 }
		 else{
		 	$arr=array(
		 		'th_name'=>$_POST['tname'],
		 		'th_areaid'=>$_POST['areaid']
		 	);

		 	$res=$this->movie_model->insert('theater',$arr);
		 	if($res>0){
		 		echo json_encode(array('status'=>'success','desc'=>'Theater added successfully.'));

			}
			else{
		 		echo json_encode(array('status'=>'error','desc'=>'Theater added failed.'));

			}
		 }
	}


	function screen(){
		$res['city']=$this->movie_model->getdb('city');
		$this->load->view('screen',$res);
	}

	function screen_action(){
		$arr=array('th_areaid'=>$_POST['th_areaid']);
		$res=$this->movie_model->getwheredb('theater',$arr);
		// print_r($res);
		if(is_array($res) && $res!='error'){
		 	// echo json_encode(array('status'=>'success','desc'=>));
			echo "<option value=' '>please select area </option>";
			foreach ($res as $val) {
				$id=$val['th_id'];
				echo "<option value='$id' >".$val['th_name']."</option>";
			}
		}
		else{
			echo "<option value=''>No area found.</option>";
		}
	}

	function screen_insertaction(){
		// print_r($_POST);
		$this->form_validation->set_rules('screen_name','Screen name','required|alpha_numeric_spaces');
		 $this->form_validation->set_rules('cityid','city','required|numeric');
		 $this->form_validation->set_rules('areaid','area','required|numeric');
		 $this->form_validation->set_rules('theaterid','Theater','required|numeric');

		 if(!$this->form_validation->run()){
		 	echo json_encode(array('status'=>'error','desc'=>validation_errors()));

		 }
		 else{
		 	$arr=array(
		 		's_name'=>$_POST['screen_name'],
		 		's_thid'=>$_POST['theaterid']
		 	);

		 	$res=$this->movie_model->insert('screen',$arr);
		 	if($res>0){
		 		echo json_encode(array('status'=>'success','desc'=>'Screen added successfully.'));

			}
			else{
		 		echo json_encode(array('status'=>'error','desc'=>'Screen added failed.'));

			}
		 }
	}
	
	function seats(){
		$res['city']=$this->movie_model->getdb('city');
		$this->load->view('add-seats',$res);
	}


	function seat_action(){
		$arr=array('s_thid'=>$_POST['th_id']);
		$res=$this->movie_model->getwheredb('screen',$arr);
		// print_r($res);
		if(is_array($res) && $res!='error'){
		 	// echo json_encode(array('status'=>'success','desc'=>));
			echo "<option value=' '>please select area </option>";
			foreach ($res as $val) {
				$id=$val['s_id'];
				echo "<option value='$id' >".$val['s_name']."</option>";
			}
		}
		else{
			echo "<option value=''>No area found.</option>";
		}
	}

	function seat_insertaction(){
		 //print_r($_POST);
		
		 $this->form_validation->set_rules('cityid','city','required|numeric');
		 $this->form_validation->set_rules('areaid','area','required|numeric');
		 $this->form_validation->set_rules('theaterid','Theater','required|numeric');
		 $this->form_validation->set_rules('screenid','Screen','required|numeric');
		 $this->form_validation->set_rules('seat_amount','Seat Amount','required|numeric');
		 $this->form_validation->set_rules('toseat','Seat','required|numeric');

		 if(!$this->form_validation->run()){
		 	echo json_encode(array('status'=>'error','desc'=>validation_errors()));

		 }
		 else{
		 	$arr=array(
		 		'se_screenid'=>$_POST['screenid'],
		 		'se_amount'=>$_POST['seat_amount'],
		 		'se_no'=>$_POST['toseat']
		 	);

		 	$res=$this->movie_model->insert('seat',$arr);
		 	if($res>0){
		 		echo json_encode(array('status'=>'success','desc'=>'seat added successfully.'));

			}
			else{
		 		echo json_encode(array('status'=>'error','desc'=>'seat added failed.'));

			}
		 }
	}

	function movies(){
		$this->load->view('movies');
	}

	function moviepicupload(){
		// print_r($_POST);
		// print_r($_FILES);
		$this->form_validation->set_rules('mname','Movie name','trim|required|alpha_numeric_spaces');
		$this->form_validation->set_rules('mdesc','Movie desc','trim|required|alpha_numeric_spaces');

		if(!$this->form_validation->run()){
		 	echo json_encode(array('status'=>'error','desc'=>validation_errors()));
		}
		
		else{
			$config['upload_path'] = base_url('assets/uploads/');
			$config['allowed_types'] = 'gif|jpg|png';
			$config['max_size']     = '1000';
			$config['max_width'] = '1024';
			$config['max_height'] = '768';
			$this->upload->initialize($config);
			 // print_r($config['upload_path']);
			if(!$this->upload->do_upload('path')){
				echo json_encode(array('status'=>'error','desc'=> $this->upload->display_errors()));
			}
			else{
				$data = array('upload_data' => $this->upload->data());
				print_r($data);
			}
		}
	}


}
