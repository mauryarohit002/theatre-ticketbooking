<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Movie extends CI_Controller {
	  function __construct() {
        parent::__construct();

        $this->load->model('movie_model');
      }  
	
	public function index()
	{
		$this->load->view('index');
	}

	function login(){
		$this->load->view('login');
	}

	function login_action(){
		// $this->load->view('login');
	}

	function register(){
		$this->load->view('register');
	}

	function register_action(){
		// $this->load->view('register');
		print_r($_POST);
	}

	
}
