<?php 
	require_once 'functions.php'; 
	interface parameter{
		const HOSTNAME = "localhost";
		const USERNAME = "root";
		const PASSWORD = "";
		const DATABASE = "pratik1";
	}