-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 04, 2018 at 04:59 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pratik1`
--

-- --------------------------------------------------------

--
-- Table structure for table `area`
--

CREATE TABLE `area` (
  `aid` int(11) NOT NULL,
  `aname` varchar(100) NOT NULL,
  `acid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `area`
--

INSERT INTO `area` (`aid`, `aname`, `acid`) VALUES
(6, 'Mulund', 1),
(7, 'Bhandup', 1),
(8, 'Thane City', 2),
(9, 'Kalyan City', 3),
(10, 'Majiwada', 2),
(11, 'kandivali', 7);

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `cid` int(11) NOT NULL,
  `cname` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`cid`, `cname`) VALUES
(1, 'Mumbai'),
(2, 'Thane'),
(3, 'Kalyan'),
(4, 'Pune'),
(5, 'Thane'),
(6, 'mumbai'),
(7, 'badlapur');

-- --------------------------------------------------------

--
-- Table structure for table `movie`
--

CREATE TABLE `movie` (
  `m` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `movies`
--

CREATE TABLE `movies` (
  `m_id` int(11) NOT NULL,
  `m_name` varchar(100) NOT NULL,
  `m_path` text NOT NULL,
  `m_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `movies`
--

INSERT INTO `movies` (`m_id`, `m_name`, `m_path`, `m_desc`) VALUES
(3, 'Tarzan', '../assets/uploads/1540376904gallery1.jpg', 'Tarzan'),
(4, 'Sanju', '../assets/uploads/1540376916gallery2.jpg', 'Sanju'),
(5, 'Saheb', '../assets/uploads/1540376929gallery3.jpg', 'Saheb'),
(6, 'w', '../assets/uploads/1540464441girl2.jpg', 'adew'),
(7, 'New Movie', '../assets/uploads/1540891898female.png', 'Some Desc Some Desc Some Desc Some Desc'),
(8, 'zero', '../assets/uploads/1541330342Desert.jpg', 'zero');

-- --------------------------------------------------------

--
-- Table structure for table `movie_screen`
--

CREATE TABLE `movie_screen` (
  `ms_id` int(11) NOT NULL,
  `ms_movieid` int(11) NOT NULL,
  `ms_screenid` int(11) NOT NULL,
  `ms_end` date NOT NULL,
  `ms_start` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `movie_screen`
--

INSERT INTO `movie_screen` (`ms_id`, `ms_movieid`, `ms_screenid`, `ms_end`, `ms_start`) VALUES
(1, 4, 1, '2018-11-06', '2018-10-20'),
(2, 4, 3, '2018-11-06', '2018-10-24'),
(3, 5, 4, '2018-11-06', '2018-10-24'),
(4, 5, 1, '2018-11-08', '2018-10-24'),
(5, 3, 2, '2018-11-08', '2018-10-24'),
(6, 4, 2, '2018-11-03', '2018-10-24'),
(7, 7, 5, '2018-11-07', '2018-10-30'),
(8, 8, 7, '2018-11-21', '2018-11-04');

-- --------------------------------------------------------

--
-- Table structure for table `screen`
--

CREATE TABLE `screen` (
  `sc_id` int(11) NOT NULL,
  `sc_name` varchar(100) NOT NULL,
  `sc_thid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `screen`
--

INSERT INTO `screen` (`sc_id`, `sc_name`, `sc_thid`) VALUES
(1, 'screen A', 3),
(2, 'screen B', 3),
(3, 'screen 1', 4),
(4, 'screen 2', 4),
(5, 'Screen A', 6),
(6, 'Screen B', 6),
(7, 'screen a', 7),
(8, 'screen b', 7),
(9, 'screen b', 7),
(10, 'screen b', 7);

-- --------------------------------------------------------

--
-- Table structure for table `seats`
--

CREATE TABLE `seats` (
  `se_id` int(11) NOT NULL,
  `se_amount` int(11) NOT NULL,
  `se_no` int(11) NOT NULL,
  `se_screen_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seats`
--

INSERT INTO `seats` (`se_id`, `se_amount`, `se_no`, `se_screen_id`) VALUES
(29, 100, 5, 1),
(30, 100, 6, 1),
(31, 250, 7, 1),
(32, 250, 8, 1),
(33, 250, 9, 1),
(34, 250, 10, 1),
(35, 100, 11, 1),
(36, 100, 12, 1),
(49, 100, 3, 1),
(50, 100, 4, 1),
(51, 250, 1, 3),
(52, 250, 2, 3),
(53, 250, 3, 3),
(54, 250, 4, 3),
(55, 250, 5, 3),
(56, 100, 6, 3),
(57, 100, 7, 3),
(58, 100, 8, 3),
(59, 100, 9, 3),
(60, 100, 10, 3),
(61, 150, 1, 4),
(62, 150, 2, 4),
(63, 150, 3, 4),
(64, 150, 4, 4),
(65, 150, 5, 4),
(66, 150, 6, 4),
(67, 150, 7, 4),
(68, 150, 8, 4),
(69, 150, 9, 4),
(70, 150, 10, 4),
(71, 100, 1, 5),
(72, 100, 2, 5),
(73, 100, 3, 5),
(74, 100, 4, 5),
(75, 100, 5, 5),
(76, 100, 6, 5),
(77, 100, 7, 5),
(78, 100, 8, 5),
(79, 100, 9, 5),
(80, 100, 10, 5),
(81, 150, 1, 6),
(82, 150, 2, 6),
(83, 150, 3, 6),
(84, 150, 4, 6),
(85, 150, 5, 6),
(86, 150, 6, 6),
(87, 150, 7, 6),
(88, 150, 8, 6),
(89, 150, 9, 6),
(90, 150, 10, 6),
(91, 150, 11, 6),
(92, 150, 12, 6),
(93, 150, 13, 6),
(94, 150, 14, 6),
(95, 150, 15, 6),
(96, 100, 1, 7),
(97, 100, 2, 7),
(98, 100, 3, 7),
(99, 100, 4, 7),
(100, 100, 5, 7),
(101, 100, 6, 7),
(102, 100, 7, 7),
(103, 100, 8, 7),
(104, 100, 9, 7),
(105, 100, 10, 7);

-- --------------------------------------------------------

--
-- Table structure for table `theater`
--

CREATE TABLE `theater` (
  `th_id` int(11) NOT NULL,
  `th_name` varchar(100) NOT NULL,
  `th_areaid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `theater`
--

INSERT INTO `theater` (`th_id`, `th_name`, `th_areaid`) VALUES
(3, 'PVR Mulund', 6),
(4, 'RMALL Thane', 8),
(5, 'RMALL Bhandup', 7),
(6, 'PVR Majiwada', 10),
(7, 'pvr badlapur', 11);

-- --------------------------------------------------------

--
-- Table structure for table `userorder`
--

CREATE TABLE `userorder` (
  `oid` int(11) NOT NULL,
  `odate` date NOT NULL,
  `oscreenid` int(11) NOT NULL,
  `omovieid` int(11) NOT NULL,
  `otid` int(11) NOT NULL,
  `oseatno` int(11) NOT NULL,
  `oamount` int(11) NOT NULL,
  `ouid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userorder`
--

INSERT INTO `userorder` (`oid`, `odate`, `oscreenid`, `omovieid`, `otid`, `oseatno`, `oamount`, `ouid`) VALUES
(1, '2018-10-31', 1, 4, 3, 5, 100, 0),
(7, '2018-10-31', 1, 4, 3, 7, 250, 0),
(8, '2018-10-31', 1, 4, 3, 12, 5, 0),
(9, '2018-11-04', 7, 8, 7, 3, 100, 0),
(10, '2018-11-04', 7, 8, 7, 10, 0, 0),
(11, '2018-11-04', 7, 8, 7, 6, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `name` varchar(100) DEFAULT NULL,
  `mobile` bigint(11) DEFAULT NULL,
  `emailid` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `status` tinyint(4) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`name`, `mobile`, `emailid`, `password`, `id`, `status`) VALUES
('xyz', 8965896523, 'pratik1@gmail.com', '70c881d4a26984ddce795f6f71817c9cf4480e79', 11, 1),
('nilay', 9619404202, 'nilay@gmail.com', '70c881d4a26984ddce795f6f71817c9cf4480e79', 12, 0),
('rahul', 9619404202, 'rahul@gmail.com', '70c881d4a26984ddce795f6f71817c9cf4480e79', 13, 1),
('priyanka', 2345, 'priyanka@gmail.com', 'd2f75e8204fedf2eacd261e2461b2964e3bfd5be', 14, 0),
('rahul', 9809809800, 'rahula@gmail.com', '70c881d4a26984ddce795f6f71817c9cf4480e79', 15, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `area`
--
ALTER TABLE `area`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `movies`
--
ALTER TABLE `movies`
  ADD PRIMARY KEY (`m_id`);

--
-- Indexes for table `movie_screen`
--
ALTER TABLE `movie_screen`
  ADD PRIMARY KEY (`ms_id`);

--
-- Indexes for table `screen`
--
ALTER TABLE `screen`
  ADD PRIMARY KEY (`sc_id`);

--
-- Indexes for table `seats`
--
ALTER TABLE `seats`
  ADD PRIMARY KEY (`se_id`);

--
-- Indexes for table `theater`
--
ALTER TABLE `theater`
  ADD PRIMARY KEY (`th_id`);

--
-- Indexes for table `userorder`
--
ALTER TABLE `userorder`
  ADD PRIMARY KEY (`oid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `area`
--
ALTER TABLE `area`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `movies`
--
ALTER TABLE `movies`
  MODIFY `m_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `movie_screen`
--
ALTER TABLE `movie_screen`
  MODIFY `ms_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `screen`
--
ALTER TABLE `screen`
  MODIFY `sc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `seats`
--
ALTER TABLE `seats`
  MODIFY `se_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=106;

--
-- AUTO_INCREMENT for table `theater`
--
ALTER TABLE `theater`
  MODIFY `th_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `userorder`
--
ALTER TABLE `userorder`
  MODIFY `oid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
