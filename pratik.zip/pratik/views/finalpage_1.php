<?php  
	session_start();
	$_SESSION['start'] = $_POST['date_selected'];
            $_SESSION['screenid'] = $_POST['screenid'];
            $_SESSION['movieid'] = $_POST['movieid'];
            $_SESSION['theaterid'] = $_POST['theaterid'];
            $_SESSION['seatno'] = $_POST['seatno'];
            $_SESSION['seatamount'] = $_POST['seatamount'];
            $_SESSION['totalamount'] = $_POST['totalamount'];
            header("location:finalpage.php");
?>