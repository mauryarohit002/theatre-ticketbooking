<script type="text/javascript">
	window.location.href="views/index.php";
</script>